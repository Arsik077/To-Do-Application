package com.example.TestProgram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestProgramApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestProgramApplication.class, args);
	}

}
